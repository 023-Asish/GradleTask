package com.example.GradleTask;

import annotation.ClassDoc;
import annotation.MethodDoc;

/**
 * B javadoc
 */
public class B {
    /**
     * BMethod1 javadoc
     */
    @MethodDoc("BMethod1")
    public void BMethod1(){

    }

    /**
     * BMethod2 javadoc
     */
    @MethodDoc("BMethod2")
    public void BMethod2(){

    }
}