package com.example.GradleTask;

import annotation.ClassDoc;
import annotation.MethodDoc;

/**
 * C javadoc
 */
@ClassDoc("C")
public class C {
    /**
     * CMethod1 javadoc
     */
    @MethodDoc("CMethod1")
    public void CMethod1(){

    }

    /**
     * CMethod2 javadoc
     */
    @MethodDoc("CMethod2")
    public void CMethod2(){

    }
}
