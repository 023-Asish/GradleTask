package com.example.GradleTask;

import annotation.ClassDoc;
import annotation.MethodDoc;

/**
 * E javadoc
 */
@ClassDoc("E")
public class E {
    /**
     * EMethod1 javadoc
     */
    @MethodDoc("EMethod1")
    public void EMethod1() {

    }

    /**
     * EMethod2 javadoc
     */
    @MethodDoc("EMethod2")
    public void EMethod2() {

    }
}

