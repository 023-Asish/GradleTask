package com.example.GradleTask;

import annotation.ClassDoc;
import annotation.MethodDoc;

/**
 * D javadoc
 */
@ClassDoc("D")
public class D {
    /**
     * DMethod1 javadoc
     */
    @MethodDoc("DMethod1")
    public void DMethod1() {

    }

    /**
     * DMethod2 javadoc
     */
    @MethodDoc("DMethod2")
    public void DMethod2() {

    }

}

