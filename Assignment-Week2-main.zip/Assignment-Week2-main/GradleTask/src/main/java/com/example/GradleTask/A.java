package com.example.GradleTask;

import annotation.ClassDoc;
import annotation.MethodDoc;

@ClassDoc("A")
public class A {
    /**
     * A Method1 javadoc
     */
    @MethodDoc("A Method1")
    public void AMethod1(){

    }

    /**
     * A-Method2 javadoc
     */
    @MethodDoc("A Method2")
    public void AMethod2(){

    }
}
