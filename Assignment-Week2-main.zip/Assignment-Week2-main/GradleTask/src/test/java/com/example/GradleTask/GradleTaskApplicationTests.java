package com.example.GradleTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
